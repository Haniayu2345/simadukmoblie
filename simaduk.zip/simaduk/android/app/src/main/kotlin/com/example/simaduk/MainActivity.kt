package com.example.simaduk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
