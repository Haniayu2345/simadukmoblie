import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:simaduk/screens/login_page.dart';  // Assuming you have a LoginPage screen
import 'pengaturan_page.dart';

class ProfilePage extends StatelessWidget {
  // Function to clear session data and log out
  Future<void> logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();  // Clears all data from SharedPreferences

    // Navigate to the login page (replace LoginPage() with your actual login screen widget)
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profil"),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50,
              backgroundColor: const Color.fromARGB(255, 33, 99, 55),
              child: Icon(Icons.account_circle, size: 80, color: Colors.white),
            ),
            SizedBox(height: 10),
            Text(
              "Nama Pengguna",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Text("nama@email.com", style: TextStyle(color: Colors.grey)),
            SizedBox(height: 20),
            ListTile(
              leading: Icon(Icons.settings, color: const Color.fromARGB(255, 33, 99, 55)),
              title: Text("Pengaturan"),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => PengaturanPage()));
              },
            ),
            ListTile(
              leading: Icon(Icons.logout, color: Colors.red),
              title: Text("Keluar"),
              onTap: () {
                logout(context);  // Call the logout function
              },
            ),
          ],
        ),
      ),
    );
  }
}
