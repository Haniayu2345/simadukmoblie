import 'package:flutter/material.dart';
import 'package:simaduk/screens/login_page.dart';
import 'dart:async';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  double _progress = 0.0;
  int _progressPercentage = 0;

  @override
  void initState() {
    super.initState();
    startLoading();
  }

  void startLoading() {
    Timer.periodic(Duration(milliseconds: 20), (timer) {
      if (_progress < 1) {
        setState(() {
          _progress += 0.01; // Menambah progress bar sedikit demi sedikit
          _progressPercentage = (_progress * 100).toInt(); // Update persen
        });
      } else {
        timer.cancel();
        // Setelah progress penuh, pindah ke HomePage
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset("assets/logo11.png", height: 120), // Logo aplikasi
            SizedBox(height: 20),
            Text(
              "Simaduk",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: ClipRRect(
                borderRadius:
                    BorderRadius.circular(10), // Tambahkan border radius
                child: LinearProgressIndicator(
                  value: _progress,
                  backgroundColor: Colors.grey[300],
                  valueColor: AlwaysStoppedAnimation<Color>(
                      const Color.fromARGB(255, 33, 99, 55)),
                  minHeight: 20,
                ),
              ),
            ),
            SizedBox(height: 10),
            Text(
              "$_progressPercentage%", // Menampilkan persen progress
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
