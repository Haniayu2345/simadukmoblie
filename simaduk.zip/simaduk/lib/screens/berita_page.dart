// import 'package:flutter/material.dart';

// class BeritaPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Berita Desa"),
//       ),
//       body: Center(
//         child: Text(
//           "Halaman Berita Desa",
//           style: TextStyle(fontSize: 18),
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

class NewsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      // appBar: AppBar(
      //   backgroundColor: Colors.white,
      //   elevation: 3,
      //   title: Text("Berita",
      //       style: TextStyle(
      //           color: Color(0xFF216337), fontWeight: FontWeight.bold)),
      // ),
      body: Center(
        child: Text("Halaman Berita",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ),
    );
  }
}

