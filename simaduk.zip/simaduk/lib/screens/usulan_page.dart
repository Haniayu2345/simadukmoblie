// import 'package:flutter/material.dart';

// class KeuanganPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Keuangan Desa"),
//       ),
//       body: Center(
//         child: Text(
//           "Halaman Keuangan Desa",
//           style: TextStyle(fontSize: 18),
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';

class UsulanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 3,
        title: Text("Usulan",
            style: TextStyle(
                color: Color(0xFF216337), fontWeight: FontWeight.bold)),
      ),
      body: Center(
        child: Text("Halaman Usulan",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
