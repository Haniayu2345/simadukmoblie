import 'package:flutter/material.dart';

class AgendaPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text("Agenda Desa"),
      // ),
      body: Center(
        child: Text(
          "Halaman Agenda Desa",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
