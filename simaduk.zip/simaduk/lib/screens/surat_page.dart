import 'package:flutter/material.dart';

class SuratPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Layanan Surat"),
      ),
      body: Center(
        child: Text(
          "Halaman Layanan Surat",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
