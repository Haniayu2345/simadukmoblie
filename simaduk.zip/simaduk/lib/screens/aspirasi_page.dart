// import 'package:flutter/material.dart';

// class PendudukPage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Data Penduduk"),
//       ),
//       body: Center(
//         child: Text(
//           "Halaman Data Penduduk",
//           style: TextStyle(fontSize: 18),
//         ),
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';

class AspirasiPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      // appBar: AppBar(
      //   backgroundColor: Colors.white,
      //   elevation: 3,
      //   title: Text("Aspirasi",
      //       style: TextStyle(
      //           color: Color(0xFF216337), fontWeight: FontWeight.bold)),
      // ),
      body: Center(
        child: Text("Halaman Aspirasi",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ),
    );
  }
}
