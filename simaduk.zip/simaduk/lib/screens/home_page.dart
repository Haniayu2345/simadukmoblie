// import 'package:flutter/material.dart';
// import 'package:animated_text_kit/animated_text_kit.dart';
// import 'package:simaduk/screens/surat_page.dart';
// import 'package:simaduk/screens/aspirasi_page.dart';
// import 'package:simaduk/screens/agenda_page.dart';
// import 'package:simaduk/screens/usulan_page.dart';
// import 'package:simaduk/screens/berita_page.dart';
// import 'package:simaduk/screens/profile_page.dart';

// class HomePage extends StatelessWidget {
//   final String userName = "Rizal"; // Bisa diganti dengan nama user dari backend

//   @override
//   Widget build(BuildContext context) {
//     print("Memuat halaman HomePage...");

//     return Scaffold(
//       backgroundColor: Colors.grey[100],
//       appBar: AppBar(
//         backgroundColor: Colors.white,
//         elevation: 0,
//         title: Text(
//           "SIMADUK",
//           style: TextStyle(
//             color: const Color.fromARGB(255, 33, 99, 55),
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         actions: [
//           IconButton(
//             icon: Icon(Icons.notifications,
//                 color: const Color.fromARGB(255, 33, 99, 55)),
//             onPressed: () {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 SnackBar(content: Text("Notifikasi belum tersedia")),
//               );
//             },
//           ),
//           IconButton(
//             icon: Icon(
//               Icons.account_circle,
//               color: const Color.fromARGB(255, 33, 99, 55),
//               size: 28,
//             ),
//             onPressed: () {
//               Navigator.push(context,
//                   MaterialPageRoute(builder: (context) => ProfilePage()));
//             },
//           ),
//         ],
//       ),
//       body: SingleChildScrollView(
//         child: Padding(
//           padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               // Animasi Selamat Datang dengan Nama User
//               Center(
//                 child: AnimatedTextKit(
//                   repeatForever: true,
//                   animatedTexts: [
//                     TypewriterAnimatedText(
//                       "Selamat datang, $userName!",
//                       textStyle: TextStyle(
//                         fontSize: 16,
//                         fontWeight: FontWeight.bold,
//                         color: const Color.fromARGB(255, 33, 99, 55),
//                       ),
//                       speed: Duration(milliseconds: 100),
//                     ),
//                     TypewriterAnimatedText(
//                       "", // Efek menghilang
//                       textStyle: TextStyle(
//                         fontSize: 16,
//                         fontWeight: FontWeight.bold,
//                         color: const Color.fromARGB(255, 33, 99, 55),
//                       ),
//                       speed: Duration(milliseconds: 50),
//                     ),
//                   ],
//                 ),
//               ),
//               SizedBox(height: 20),

//               // Judul Layanan Desa
//               Text(
//                 "Layanan Desa",
//                 style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
//               ),
//               SizedBox(height: 15),

//               // Grid Layanan Desa - Tampilan lebih kecil dan bulat
//               GridView.count(
//                 shrinkWrap: true,
//                 physics: NeverScrollableScrollPhysics(),
//                 crossAxisCount: 5, // Menampilkan 5 menu per baris
//                 crossAxisSpacing: 6,
//                 mainAxisSpacing: 6,
//                 children: [
//                   _buildMenuItem(
//                       context, Icons.article, "Aspirasi", SuratPage()),
//                   _buildMenuItem(
//                       context, Icons.people, "Penduduk", PendudukPage()),
//                   _buildMenuItem(
//                       context, Icons.calendar_today, "Agenda", AgendaPage()),
//                   _buildMenuItem(
//                       context, Icons.attach_money, "Keuangan", KeuanganPage()),
//                   _buildMenuItem(context, Icons.public, "Berita", BeritaPage()),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   // Fungsi untuk membuat menu
//   Widget _buildMenuItem(
//       BuildContext context, IconData icon, String label, Widget? page) {
//     print("Membuat menu: $label"); // Debugging

//     return GestureDetector(
//       onTap: () {
//         print("Menu $label ditekan");
//         if (page != null) {
//           Navigator.push(
//               context, MaterialPageRoute(builder: (context) => page));
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(content: Text("Halaman $label belum tersedia")),
//           );
//         }
//       },
//       child: Column(
//         children: [
//           Container(
//             width: 50, // Ukuran lingkaran lebih kecil
//             height: 50,
//             decoration: BoxDecoration(
//               color: Colors.white,
//               shape: BoxShape.circle, // Membuat ikon berbentuk lingkaran
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.grey.withOpacity(0.2),
//                   blurRadius: 4,
//                   spreadRadius: 1,
//                 ),
//               ],
//             ),
//             child: Center(
//               child: Icon(icon,
//                   size: 20,
//                   color: const Color.fromARGB(
//                       255, 33, 99, 55)), // Ikon lebih kecil
//             ),
//           ),
//           SizedBox(height: 4),
//           Text(label, style: TextStyle(fontSize: 10)), // Teks lebih kecil
//         ],
//       ),
//     );
//   }
// }
