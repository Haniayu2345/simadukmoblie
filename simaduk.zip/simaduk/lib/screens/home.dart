import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'profile_page.dart';
import 'berita_page.dart';
import 'aspirasi_page.dart';
import 'usulan_page.dart';

class HehePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HehePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    HomePageContent(),
    NewsPage(),
    AspirasiPage(),
    UsulanPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          "SIMADUK",
          style: GoogleFonts.poppins(
            color: Color(0xFF216337),
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.notifications_outlined, color: Color(0xFF216337)),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Notifikasi belum tersedia")),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.account_circle_outlined,
                color: Color(0xFF216337), size: 28),
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ProfilePage()));
            },
          ),
        ],
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: Color(0xFF216337),
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
        showUnselectedLabels: false,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home_rounded), label: "Beranda"),
          BottomNavigationBarItem(
              icon: Icon(Icons.article_rounded), label: "Berita"),
          BottomNavigationBarItem(
              icon: Icon(Icons.forum_rounded), label: "Aspirasi"),
          BottomNavigationBarItem(
              icon: Icon(Icons.send_rounded), label: "Usulan"),
        ],
      ),
    );
  }
}

class HomePageContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildBanner(),
          SizedBox(height: 20),
          _buildSectionTitle("Berita Terbaru"),
          _buildNewsList(),
          SizedBox(height: 20),
          _buildSectionTitle("Berita Desa"),
          _buildVillageNews(),
        ],
      ),
    );
  }

  Widget _buildBanner() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: Color(0xFF216337),
      ),
      padding: EdgeInsets.all(18),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Dukung Digitalisasi Desa\nBersama SIMADUK",
                  style: GoogleFonts.poppins(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  "Rengasdengklok - Karawang",
                  style:
                      GoogleFonts.poppins(color: Colors.white70, fontSize: 14),
                ),
              ],
            ),
          ),
          Icon(Icons.eco_rounded, color: Colors.white, size: 50),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: GoogleFonts.poppins(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Color(0xFF216337),
        ),
      ),
    );
  }

  Widget _buildNewsList() {
    return Container(
      height: 170,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 3,
        itemBuilder: (context, index) {
          return Container(
            width: 210,
            margin: EdgeInsets.only(right: 12, top: 8),
            child: Card(
              color: Colors.white,
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(12)),
                    child: Image.asset(
                       'assets/berita1.jpg',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: 90,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8),
                    child: Text(
                      "Berita Terbaru",
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildVillageNews() {
    return Column(
      children: List.generate(2, (index) {
        return Card(
          color: Colors.white,
          elevation: 4,
          margin: EdgeInsets.symmetric(vertical: 8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/berita1.jpg',
                fit: BoxFit.cover,
                width: 60,
                height: 60,
              ),
            ),
            title: Text(
              "Judul Berita",
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
            subtitle: Text(
              "Lorem Ipsum is simply dummy text of the printing industry.",
              style: GoogleFonts.poppins(fontSize: 12),
            ),
          ),
        );
      }),
    );
  }
}
