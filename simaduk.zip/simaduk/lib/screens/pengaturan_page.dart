import 'package:flutter/material.dart';

class PengaturanPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pengaturan"),
      ),
      body: Center(
        child: Text(
          "Halaman Pengaturan",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
